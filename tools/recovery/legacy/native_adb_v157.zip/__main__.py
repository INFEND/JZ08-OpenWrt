#!/usr/bin/env python3
# coding: utf-8
"""XARKON JZ08 15.7: legacy Native ADB + verified stale termux-adb server cleanup.
A manual --bootloader flag enables non-flashing OEM bootloader entry after strict device checks.
"""
import os,sys,re,json,datetime,time,subprocess,shlex,hashlib,zipfile,html,argparse,traceback
from pathlib import Path
P=argparse.ArgumentParser(description='XARKON JZ08: проверенный Native ADB, проверка USB-транспорта')
P.add_argument('--bootloader',action='store_true',help='после строгой идентификации перезагрузить MiFi в загрузчик и найти Fastboot')
P.add_argument('--watch-seconds',type=int,default=45,help='время ожидания Native ADB: 10..120 секунд')
P.add_argument('--no-color',action='store_true')
P.add_argument('--keep-termux-adb',action='store_true',help='не останавливать фоновые процессы termux-adb (при возможных параллельных сессиях)')
P.add_argument('--self-test',action='store_true',help='локальная проверка без подключения к устройству')
A=P.parse_args()
PORT=5063
PREFIX=os.environ.get('PREFIX','/data/data/com.termux/files/usr')
ADB=str(Path(PREFIX)/'bin'/'adb');FASTBOOT=str(Path(PREFIX)/'bin'/'fastboot')
HOME='/data/data/com.termux/files/home';TMP=str(Path(PREFIX)/'tmp')
DL=Path('/storage/emulated/0/Download');OUT=DL/'XARKON_JZ08_REPORTS'
WATCH=max(10,min(120,A.watch_seconds));COLOR=sys.stdout.isatty() and not A.no_color and not os.getenv('NO_COLOR')
C={'ok':'\x1b[92m','warn':'\x1b[93m','info':'\x1b[96m','err':'\x1b[91m','title':'\x1b[95m','end':'\x1b[0m'}
def col(s,k):return C.get(k,'')+str(s)+C['end'] if COLOR else str(s)
def log(status,txt):
 k={'ГОТОВО':'ok','ВНИМАНИЕ':'warn','ОШИБКА':'err','ЭТАП':'title','ИНФО':'info'}.get(status,'info')
 print(col('['+status+']',k),txt,flush=True)
def section(t):print('\n'+col('═'*60+'\n '+t+'\n'+'═'*60,'title'),flush=True)
def redact(s):
 s=re.sub(r'(?im)^.*(?:IMEI|IMSI|ICCID|MAC(?:ADDRESS)?|password|passwd|serialno|serial.number|key=).*$','[СКРЫТО: приватные данные]',str(s))
 s=re.sub(r'\b\d{14,20}\b','[СКРЫТО]',s)
 return s
REPORT={'version':'15.7','mode':'Нативный ADB v15.2 + точечное освобождение USB','date':datetime.datetime.now().isoformat(timespec='seconds'),'port':PORT,'adb_libusb':'0','read_only':not A.bootloader,'bootloader_requested':bool(A.bootloader),'steps':{},'summary':{'state':'started','connected':False,'usb_transfer_started':False,'emmc_writes':0},'events':[]}
def record(n,res):
 REPORT['steps'][n]={'returncode':res['rc'],'stdout':redact(res['out'])[-6000:],'stderr':redact(res['err'])[-4000:]}
 return res
def shell_cmd(args,timeout=12):
 try:
  p=subprocess.run(args,capture_output=True,timeout=timeout,check=False)
  return {'rc':p.returncode,'out':p.stdout.decode('utf-8','replace'),'err':p.stderr.decode('utf-8','replace')}
 except subprocess.TimeoutExpired as e:
  o=e.stdout or b'';s=e.stderr or b''
  return {'rc':124,'out':o.decode('utf-8','replace') if isinstance(o,bytes) else str(o),'err':s.decode('utf-8','replace') if isinstance(s,bytes) else str(s)}
 except Exception as e:return {'rc':125,'out':'','err':repr(e)}
def root(cmd,timeout=12):return shell_cmd(['su','-c',cmd],timeout)
def adb(*args,timeout=15,trace=False):
 # Legacy v15.2 environment, not termux-adb.
 env=f'HOME={shlex.quote(HOME)} TMPDIR={shlex.quote(TMP)} ADB_LIBUSB=0 ADB_SERVER_PORT={PORT}'
 if trace:env+=' ADB_TRACE=usb,transport'
 cli=' '.join(shlex.quote(str(x)) for x in [ADB,'-P',str(PORT),*args])
 return root('env '+env+' '+cli,timeout)
def fastboot(*args,timeout=18):
 cli=' '.join(shlex.quote(str(x)) for x in [FASTBOOT,*args]);return root('env HOME='+shlex.quote(HOME)+' '+cli,timeout)
def parse_devices(s):
 a=[]
 for line in s.splitlines():
  m=re.match(r'^([^\s]+)\s+(device|offline|unauthorized)\b(.*)$',line.strip())
  if m:a.append({'serial':m.group(1),'status':m.group(2),'info':m.group(3)})
 return a
def valid_target(a):
 x=[i for i in a if i['status']=='device' and re.search(r'\bmodel:MIFI\b',i['info'],re.I) and re.search(r'\bproduct:MIFI\b',i['info'],re.I)]
 return x[0] if len(x)==1 and len(a)==1 else None
def timebar(x,total,text):
 w=27;n=max(0,min(w,int(w*x/max(1,total))));pct=min(100,int(100*x/max(1,total)))
 print('\r'+col(f'[{"█"*n}{"░"*(w-n)}] {pct:3d}%','info')+f'  {text} · {x}/{total} сек  ',end='',flush=True)
def usb_data():
 cmd=r"""for d in /sys/bus/usb/devices/*; do
 [ -r "$d/idVendor" ] || continue
 v=$(cat "$d/idVendor" 2>/dev/null); p=$(cat "$d/idProduct" 2>/dev/null)
 [ "$v" = "05c6" ] || continue
 echo "DEVICE=${d##*/} VIDPID=$v:$p"
 for i in "$d":*; do
  [ -r "$i/bInterfaceClass" ] || continue
  echo "IFACE=${i##*/} CLASS=$(cat "$i/bInterfaceClass") SUB=$(cat "$i/bInterfaceSubClass") PROTO=$(cat "$i/bInterfaceProtocol")"
  if [ -L "$i/driver" ]; then echo "DRIVER=${i##*/}:$(readlink "$i/driver")"; fi
 done
 if [ -r "$d/authorized" ]; then echo "AUTHORIZED=$(cat "$d/authorized")"; fi
done"""
 return record('usb_sysfs',root(cmd,10))
def process_info(stage='before'):
 # Root reads only /proc/*/exe and no private CLI data. Android ps often calls termux-adb simply "adb".
 cmd=r"""for p in $(pidof adb termux-adb 2>/dev/null); do
  case "$p" in *[!0-9]*|'') continue ;; esac
  exe=$(readlink /proc/$p/exe 2>/dev/null) || exe=''
  [ -n "$exe" ] && printf 'PID=%s EXE=%s\n' "$p" "$exe"
 done"""
 r=record('adb_processes_'+stage,root(cmd,12))
 paths=[]
 for line in r['out'].splitlines():
  m=re.fullmatch(r'PID=(\d+) EXE=(\S.*)',line.strip())
  if m:paths.append((int(m.group(1)),m.group(2)))
 native=[p for p,e in paths if e==ADB or e==ADB+' (deleted)']
 patched=[p for p,e in paths if e in (str(Path(PREFIX)/'bin'/'termux-adb'),str(Path(PREFIX)/'bin'/'termux-adb')+' (deleted)')]
 REPORT['steps']['adb_processes_'+stage]['types']={'native_adb':native,'termux_adb':patched,'other_count':len(paths)-len(native)-len(patched)}
 event('ИНФО',f'Процессы ADB: штатный={len(native)}, termux-adb={len(patched)}, другие={len(paths)-len(native)-len(patched)}')
 return patched

def terminate_only_termux_adb(pids):
 if not pids:
  event('ИНФО','Фоновых процессов termux-adb не найдено, остановка не требуется.');return
 if A.keep_termux_adb:
  event('ВНИМАНИЕ','По --keep-termux-adb процессы termux-adb не останавливались.');return
 # For the known stale USB holder only: process identity is rechecked immediately before each SIGTERM.
 # No generic pkill, no USB reset and never terminate the stock adb executable.
 termux_binary=str(Path(PREFIX)/'bin'/'termux-adb')
 for pid in sorted(set(pids)):
  cmd=(f'exe=$(readlink /proc/{pid}/exe 2>/dev/null) || exit 3; '
       f'case "$exe" in {shlex.quote(termux_binary)}|{shlex.quote(termux_binary+" (deleted)")}) '
       f'kill -TERM {pid} && echo "STOPPED={pid}" ;; '
       '*) echo "NOT_TERMUX_ADB"; exit 4 ;; esac')
  rr=record(f'termux_adb_stop_{pid}',root(cmd,8))
  if rr['rc']==0 and f'STOPPED={pid}' in rr['out']:
   event('ГОТОВО',f'Остановлен только фоновый termux-adb, PID {pid}')
  else:
   event('ВНИМАНИЕ',f'PID {pid}: не подтверждён как termux-adb или уже завершился')
 time.sleep(2)

def report_write():
 section('07 / ZIP-ОТЧЁТ')
 try:
  OUT.mkdir(parents=True,exist_ok=True)
  path=OUT/('XARKON_JZ08_LEGACY_ADB_V157_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'.zip')
  body=('XARKON JZ08 · Native ADB v15.7\n'+'='*45+'\n'+
   'Состояние: '+REPORT['summary'].get('state','неизвестно')+'\n'+
   'Native ADB: ADB_LIBUSB=0, порт 5063, root Samsung\n'+
   'USB-передача RAMBoot не выполнялась. eMMC не записывалась.\n'+
   'Флаг --bootloader: '+('включён' if A.bootloader else 'выключен')+'\n\n'+
   '\n'.join('['+k+'] '+v for k,v in REPORT['events'])+'\n')
  html_doc="""<!doctype html><html lang="ru"><meta charset="utf-8"><title>XARKON · JZ08</title>
  <style>body{background:#080f1d;color:#dfeafa;font:16px system-ui;padding:32px;max-width:880px;margin:auto}h1{color:#b49aff}pre{background:#111d30;padding:20px;border-radius:14px;white-space:pre-wrap;line-height:1.6}</style><h1>XARKON // JZ08</h1><pre>"""+html.escape(body)+'</pre></html>'
  with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
   z.writestr('ОТЧЁТ.txt',body);z.writestr('ОТЧЁТ.html',html_doc);z.writestr('report.json',json.dumps(REPORT,indent=2,ensure_ascii=False))
  log('ГОТОВО','Отчёт: '+str(path));log('ИНФО','SHA-256: '+hashlib.sha256(path.read_bytes()).hexdigest()[:22]+'…')
 except Exception as e:log('ОШИБКА','Не удалось создать отчёт: '+str(e))
def event(k,s):REPORT['events'].append((k,s));log(k,s)
def run():
 print(col('\n╔'+'═'*58+'╗\n║       X A R K O N   //   J Z 0 8   v15.7             ║\n║       LEGACY NATIVE ADB · USB RECOVERY                 ║\n╚'+'═'*58+'╝','info'))
 log('ИНФО','На основе УСПЕШНОГО оригинала v15.2 · root Samsung · ADB_LIBUSB=0 · порт 5063')
 log('ИНФО','eMMC не изменяется. Только проверенные процессы termux-adb могут быть завершены (если не указан --keep-termux-adb).')
 if A.self_test:
  t='List of devices attached\n0 device usb:1-1 product:MIFI model:MIFI device:MIFI transport_id:1\n'
  assert valid_target(parse_devices(t))
  assert not valid_target(parse_devices('List of devices attached\n'))
  assert not valid_target(parse_devices('List of devices attached\n0 unauthorized\n'))
  assert 'MIFI' in valid_target(parse_devices(t))['info'];event('ГОТОВО','Внутренние тесты выбора MIFI пройдены');REPORT['summary']['state']='self_test_ok';return
 section('01 / ПРОВЕРКА ROOT И РЕЖИМА USB')
 u=record('root',root('id -u; getenforce 2>/dev/null || true',8))
 if u['rc']!=0 or (u['out'].splitlines()[:1]!=['0']):
  event('ОШИБКА','На S24 Ultra нет подтверждённого Magisk root');REPORT['summary']['state']='no_root';return
 event('ГОТОВО','Magisk root доступен');usb=usb_data()
 if not re.search(r'05c6:(9024|9091)',usb['out'],re.I):
  event('ВНИМАНИЕ','Режим USB отличается от ожидаемого 9024/9091 или роутер не подключён')
 if not re.search(r'CLASS=ff SUB=42 PROTO=01',usb['out'],re.I):
  event('ОШИБКА','USB-интерфейс ADB FF:42:01 не подтверждён');REPORT['summary']['state']='usb_not_adb';return
 event('ГОТОВО','USB-интерфейс ADB FF:42:01 найден')
 if not os.path.isfile(ADB):event('ОШИБКА','Нативный adb не установлен: '+ADB);REPORT['summary']['state']='native_adb_missing';return
 section('02 / КОНФЛИКТЫ USB: ВОЗВРАТ К РАБОЧЕМУ ADB')
 competitors=process_info('before')
 if competitors:
  event('ВНИМАНИЕ','Найден termux-adb: он может удерживать USB-интерфейс JZ08.')
  # Stop own root legacy server before releasing competing USB descriptors.
  record('native_server_stop_for_recovery',adb('kill-server',timeout=10))
 terminate_only_termux_adb(competitors)
 process_info('after')
 usb_data()
 section('03 / ПРОВЕРЕННЫЙ NATIVE ADB v15.2')
 vers=record('adb_version',adb('version',timeout=9))
 if vers['rc']:event('ОШИБКА','ADB не запускается: '+vers['err'][-300:]);REPORT['summary']['state']='adb_bin_fail';return
 st=record('adb_start',adb('start-server',timeout=20))
 if st['rc']:
  event('ОШИБКА','Нативный сервер не запущен: '+st['err'][-400:]);REPORT['summary']['state']='adb_server_fail';return
 event('ГОТОВО','Native ADB запущен через root на порту 5063')
 section('04 / USB-ТРАНСПОРТ · ОЖИДАНИЕ В РЕАЛЬНОМ ВРЕМЕНИ')
 event('ИНФО','Шкала ниже показывает ВРЕМЯ ОЖИДАНИЯ, а не передачу образа.')
 t0=time.monotonic();attempt=0;target=None;restarted=False;maxtries=50
 while attempt<maxtries and time.monotonic()-t0<WATCH:
  attempt+=1
  d=record('devices_'+str(attempt),adb('devices','-l',timeout=10))
  devices=parse_devices(d['out']);REPORT['summary']['last_devices_states']=[{'state':e['status'],'mifi':('model:MIFI' in e['info'])} for e in devices]
  candidate=valid_target(devices)
  if candidate:
   target=candidate;print();event('ГОТОВО','MIFI появился в ADB, состояние device. Попытка '+str(attempt));break
  if devices:
   event('ВНИМАНИЕ','ADB видит USB-устройство, но цель не авторизована / не идентифицирована: '+','.join(e['status'] for e in devices))
  elapsed=int(time.monotonic()-t0);timebar(elapsed,WATCH,'Ожидание MIFI')
  if elapsed>=10 and not restarted:
   print();section('05 / ПОВТОРНЫЙ ЗАПУСК ТОЛЬКО СВОЕГО ADB 5063')
   r=record('adb_kill_5063',adb('kill-server',timeout=8));r=record('adb_relaunch_trace',adb('start-server',timeout=15,trace=True))
   restarted=True;event('ИНФО','Повторно запущен только Native ADB 5063.')
  time.sleep(2)
 print()
 if not target:
  event('ИНФО','Устаревшие adb.*.log не используются: они смешивают записи предыдущих сеансов.')
  process_info('failed')
  usb_data()
  event('ВНИМАНИЕ','За '+str(WATCH)+' секунд подтверждённый MIFI не появился. Fastboot/EDL не запускались.')
  REPORT['summary']['state']='adb_usb_transport_absent'
  return
 section('06 / ИДЕНТИФИКАЦИЯ РОУТЕРА БЕЗ ЗАПИСИ')
 serial=target['serial']
 board=record('board',adb('-s',serial,'shell','getprop ro.board.platform',timeout=10))
 osver=record('android',adb('-s',serial,'shell','getprop ro.build.version.release',timeout=10))
 parts=record('partitions',adb('-s',serial,'shell','cat /proc/partitions',timeout=10))
 exact=(board['rc']==0 and board['out'].strip()=='msm8916'
  and bool(re.search(r'\b16384\s+mmcblk0p22\b',parts['out']))
  and bool(re.search(r'\b819200\s+mmcblk0p23\b',parts['out']))
  and bool(re.search(r'\b2603455\s+mmcblk0p27\b',parts['out'])))
 if not exact:
  event('ОШИБКА','Отпечаток JZ08 не совпал (MSM8916 / p22 / p23 / p27). Переход в загрузчик запрещён.')
  REPORT['summary']['state']='identity_failed';return
 event('ГОТОВО','Подтверждён заводской JZ08: MSM8916, boot p22 16 МиБ, system p23 800 МиБ')
 event('ИНФО','Android роутера: '+osver['out'].strip())
 REPORT['summary']['state']='native_adb_restored';REPORT['summary']['connected']=True
 if not A.bootloader:
  event('ИНФО','Переход в загрузчик отключён по умолчанию. Для него запусти тот же ZIP с --bootloader.')
  return
 if not os.path.isfile(FASTBOOT):
  event('ОШИБКА','Нативный fastboot отсутствует; перезагрузка запрещена.')
  REPORT['summary']['state']='fastboot_missing';return
 event('ВНИМАНИЕ','Команда reboot bootloader может привести к потере связи; запись eMMC не выполняется.')
 rr=record('reboot_bootloader',adb('-s',serial,'reboot','bootloader',timeout=13))
 if rr['rc']:
  event('ОШИБКА','Переход в загрузчик не подтверждён: '+rr['err'][-200:]);REPORT['summary']['state']='bootloader_request_failed';return
 event('ГОТОВО','Команда reboot bootloader отправлена. Ищу Native Fastboot до 20 секунд.')
 end=time.monotonic()+20
 while time.monotonic()<end:
  fb=record('fastboot_devices',fastboot('devices',timeout=8));m=re.findall(r'^([^\s]+)\s+fastboot\b',fb['out'],re.M)
  if fb['rc']==0 and len(m)==1:
   event('ГОТОВО','Обнаружен Fastboot. Перенос RAMBoot НЕ выполнялся.')
   REPORT['summary']['state']='fastboot_detected';return
  time.sleep(2)
 event('ВНИМАНИЕ','Fastboot не появился. Может потребоваться штатный перезапуск роутера.')
 REPORT['summary']['state']='bootloader_requested_no_fastboot'
if __name__=='__main__':
 try:run()
 except KeyboardInterrupt:
  REPORT['summary']['state']='interrupted';log('ВНИМАНИЕ','Прервано пользователем.')
 except Exception as e:
  REPORT['summary']['state']='script_exception';REPORT['steps']['unexpected']={'message':str(e),'traceback':traceback.format_exc()[-4500:]};log('ОШИБКА',str(e))
 finally:report_write()
