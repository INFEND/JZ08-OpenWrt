XARKON JZ08 · Legacy Native ADB v15.7

Основа: оригинальная, ранее работавшая Native ADB v15.2 (ADB_LIBUSB=0, порт 5063, su).
Изменение по отчёту 15.6: Termux запускает параллельно native adb и termux-adb.
Программа сначала проверяет /proc/PID/exe и отправляет SIGTERM ТОЛЬКО процессам с точным путём /data/data/com.termux/files/usr/bin/termux-adb.
Обычный adb, чужие приложения, мобильная сеть роутера, его прошивка и разделы eMMC не изменяются.
Побочный эффект: запущенные сеансы termux-adb могут потерять соединение. Для запрета очистки существует --keep-termux-adb.

ЗАПУСК БЕЗ РАСПАКОВКИ:
python /sdcard/Download/XARKON_JZ08_LEGACY_USB_RECOVERY_v15_7.zip

Если USB конкуренция отсутствует, скрипт просто запускает Native ADB.
Отчёт: /sdcard/Download/XARKON_JZ08_REPORTS/XARKON_JZ08_LEGACY_ADB_V157_*.zip

По умолчанию только чтение и проверка устройства. При успехе печатается "native_adb_restored".
Не применять --bootloader до оценки отчёта успешного подключения: этот параметр отправляет роутер в режим загрузчика и может отключить связь.

Время ожидания: --watch-seconds 45 (от 10 до 120)
Отказ от завершения termux-adb: --keep-termux-adb
Самопроверка: --self-test

Прогресс на экране отражает ВРЕМЯ ОЖИДАНИЯ, не скорость USB-передачи. Защита: нет EDL, reset, flash и стирания разделов.
